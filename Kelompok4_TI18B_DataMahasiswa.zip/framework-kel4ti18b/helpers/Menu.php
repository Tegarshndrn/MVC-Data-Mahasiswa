<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'home', 
			'label' => 'Data Mahasiswa', 
			'icon' => '<i class="fa fa-users "></i>'
		),
		
		array(
			'path' => 'mahasiswa/add', 
			'label' => 'Upload Data Mahasiswa', 
			'icon' => '<i class="fa fa-upload "></i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => '<i class="fa fa-user "></i>'
		)
	);
		
	
	
			public static $prodi_mhs = array(
		array(
			"value" => "Teknik Informatika", 
			"label" => "Teknik Informatika", 
		),
		array(
			"value" => "Teknik Sipil", 
			"label" => "Teknik Sipil", 
		),
		array(
			"value" => "Teknik Mesin", 
			"label" => "Teknik Mesin", 
		),
		array(
			"value" => "Teknik Elektro", 
			"label" => "Teknik Elektro", 
		),
		array(
			"value" => "PKK", 
			"label" => "Pkk", 
		),);
		
			public static $tahun_masuk = array(
		array(
			"value" => "2018-2019", 
			"label" => "2018-2019", 
		),
		array(
			"value" => "2019-2020", 
			"label" => "2019-20", 
		),
		array(
			"value" => "2020-2021", 
			"label" => "2020-2021", 
		),
		array(
			"value" => "2021-2022", 
			"label" => "2021-2022", 
		),);
		
}